﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR15_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество рабочих N=");
            int N = int.Parse(Console.ReadLine());
            clsWORKER[] worker = new clsWORKER[N];
            for (int i = 0; i < N; i++)
            {
                worker[i] = new clsWORKER();
                Console.WriteLine("введите ФИО");
                worker[i].FIO = Console.ReadLine();
                Console.WriteLine("введите должность");
                worker[i].POST = Console.ReadLine();
                Console.WriteLine("введите дату поступления");
                worker[i].DATERECEIPTS = int.Parse(Console.ReadLine());
            }
            foreach (clsWORKER cls in worker)
            {
                Console.WriteLine(cls.PrintInfo());
                cls.Save();
                cls.raschet();
            }
            Console.Write("Введите название должности для поиска: ");
            string search_word = Console.ReadLine();
            Search(worker, search_word);
            Console.ReadKey();


        }
        public static void Search(clsWORKER[] worker, string search_word)
        {
            bool flag = false;
            for (int i = 0; i < worker.Length; i++)
            {
                if (Convert.ToString(worker[i].POST) == search_word)
                {
                    Console.WriteLine(worker[i].PrintInfo());
                    flag = true;
                }
            }
            if (flag == false)
                Console.WriteLine("Работника с такой должностью не найдено");
        }
    }
}
